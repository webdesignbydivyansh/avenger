package com.example.sampleproj.adapter

import android.graphics.*
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.sampleproj.R
import com.example.sampleproj.data.GithubUserRepo
import com.squareup.picasso.Picasso
import com.squareup.picasso.Transformation

class GithubUserRepoAdapter(val githubUserRepo:ArrayList<GithubUserRepo>): RecyclerView.Adapter<GithubUserRepoAdapter.GithubUserRepoViewHolder>() {
    private lateinit var mtListener: onItemSelectListener
    interface onItemSelectListener{
        fun onItemSelect(pos:Int)
    }
    fun setOnItemSelectListener(listener: onItemSelectListener)
    {
        mtListener=listener
    }
    class GithubUserRepoViewHolder(val view: View, val listener: onItemSelectListener):RecyclerView.ViewHolder(view) {
        val txtName=view.findViewById<TextView>(R.id.nameRepo)
        val txtLang=view.findViewById<TextView>(R.id.langRepo)
        val imgRepo=view.findViewById<ImageView>(R.id.imgViewRepo)

        init {
            view.setOnClickListener {
                listener.onItemSelect(adapterPosition)
            }
        }
    }
    class CircleTransform : Transformation {
        override fun transform(source: Bitmap): Bitmap {
            val size = Math.min(source.width, source.height)

            val x = (source.width - size) / 2
            val y = (source.height - size) / 2

            val squaredBitmap = Bitmap.createBitmap(source, x, y, size, size)
            if (squaredBitmap != source) {
                source.recycle()
            }

            val bitmap = Bitmap.createBitmap(size, size, source.config)

            val canvas = Canvas(bitmap)
            val paint = Paint()
            val shader = BitmapShader(squaredBitmap,
                    Shader.TileMode.CLAMP,
                    Shader.TileMode.CLAMP)
            paint.shader = shader
            paint.isAntiAlias = true

            val r = size / 2f
            canvas.drawCircle(r, r, r, paint)

            squaredBitmap.recycle()
            return bitmap
        }

        override fun key(): String {
            return "circle"
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GithubUserRepoViewHolder {
        return GithubUserRepoViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_github_repo_single,parent,false),mtListener)
    }

    override fun onBindViewHolder(holder: GithubUserRepoViewHolder, position: Int) {
        val githubRepo=githubUserRepo[position]
        holder.txtName.text="Name: "+githubRepo.name
        holder.txtLang.text="Language: "+githubRepo.language
        Picasso.get().load(githubRepo.avatar_url).transform(CircleTransform()).into(holder.imgRepo)
    }

    override fun getItemCount(): Int {
        return githubUserRepo.size
    }
}