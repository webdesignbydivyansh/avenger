package com.example.sampleproj.data

data class GithubUser(
        val login:String,
        val id: String,
        val repos_url: String,
        val avatar_url:String,
        )