package com.example.sampleproj.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.widget.SearchView
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.sampleproj.R
import com.example.sampleproj.adapter.GithubUsersAdapter
import com.example.sampleproj.data.GithubUser
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONException

class MainActivity : AppCompatActivity() {

    var githubUserList= arrayListOf<GithubUser>()
    lateinit var recyclerAdapter: GithubUsersAdapter
    lateinit var layoutManager:RecyclerView.LayoutManager
    private lateinit var mListener: GithubUsersAdapter.onItemClickListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val queue= Volley.newRequestQueue(this)
        val url="https://api.github.com/search/users?q=divyansh"
        val recyclerGithub=findViewById<RecyclerView>(R.id.rvView)

            val jsonObjectRequest = JsonObjectRequest(Request.Method.GET, url, null,
                    {
                        try {
                            val items = it.getJSONArray("items")
                            for (i in 0 until items.length()) {
                                val gitJSONObject = items.getJSONObject(i)
                                val gitObject = GithubUser(
                                        gitJSONObject.getString("login"),
                                        gitJSONObject.getString("id"),
                                        gitJSONObject.getString("repos_url"),
                                        gitJSONObject.getString("avatar_url")
                                )
                                githubUserList.add(gitObject)
                                layoutManager = LinearLayoutManager(this@MainActivity)
                                recyclerAdapter = GithubUsersAdapter(githubUserList)

                                recyclerGithub.adapter = recyclerAdapter
                                recyclerGithub.layoutManager = layoutManager
                                recyclerAdapter.setOnItemClickListener(object : GithubUsersAdapter.onItemClickListener{
                                    override fun onItemClick(position: Int) {
                                        val j=githubUserList[position].repos_url
                                        val intt = Intent(this@MainActivity, UserRepository::class.java)
                                        intt.putExtra("repository", j)
                                        startActivity(intt)
                                    }

                                })

                            }

                        } catch (e: JSONException) {
                            Toast.makeText(this@MainActivity, "Some error occured!", Toast.LENGTH_SHORT).show()
                        }

                    },
                    {
                        Toast.makeText(this@MainActivity, "Volley error occured!", Toast.LENGTH_SHORT).show()
                    }
            )
            queue.add(jsonObjectRequest)
    }
}
