package com.example.sampleproj.main

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import com.example.sampleproj.R
import com.example.sampleproj.adapter.GithubUserRepoAdapter
import com.example.sampleproj.data.GithubUserRepo
import org.json.JSONException

class UserRepository : AppCompatActivity() {

    val githubRepoList= arrayListOf<GithubUserRepo>()
    lateinit var layoutManager:RecyclerView.LayoutManager
    lateinit var recyclerRepoAdapter: GithubUserRepoAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_repository)

        val url=intent.getStringExtra("repository")

        val queue= Volley.newRequestQueue(this)
        val recyclerGithubRepo=findViewById<RecyclerView>(R.id.rvViewRepo)

        val jsonArrayRequest = JsonArrayRequest(Request.Method.GET, url, null,
                {
                    try {
                        for(i in 0 until it.length())
                        {
                            val gitJsonArray=it.getJSONObject(i)
                            val gitObject= GithubUserRepo(
                                    gitJsonArray.getString("name"),
                                    gitJsonArray.getString("language"),
                                    gitJsonArray.getString("issues_url"),
                                    gitJsonArray.getJSONObject("owner").getString("avatar_url")
                            )
                            githubRepoList.add(gitObject)
                            layoutManager=LinearLayoutManager(this)
                            recyclerRepoAdapter= GithubUserRepoAdapter(githubRepoList)
                            recyclerGithubRepo.adapter=recyclerRepoAdapter
                            recyclerGithubRepo.layoutManager=layoutManager
                            recyclerRepoAdapter.setOnItemSelectListener(object : GithubUserRepoAdapter.onItemSelectListener{
                                override fun onItemSelect(pos: Int) {
                                    val j=githubRepoList[pos].issues_url
                                    val intent=Intent(this@UserRepository, RepoActivity::class.java)
                                    intent.putExtra("issues",j)
                                    intent.putExtra("open_issues",gitJsonArray.getInt("open_issues"))
                                    startActivity(intent)
                                }

                            })
                        }

                    } catch (e: JSONException) {
                        Toast.makeText(this, "Some error occured!", Toast.LENGTH_SHORT).show()
                    }

                },
                {
                    Toast.makeText(this, "Volley error occured!", Toast.LENGTH_SHORT).show()
                }
        )
        queue.add(jsonArrayRequest)
    }
}