package com.example.sampleproj.data

data class GithubUserRepo (
        val name:String,
        val language:String,
        val issues_url:String,
        val avatar_url:String
        )