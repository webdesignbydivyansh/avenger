package com.example.sampleproj.main

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.sampleproj.R

class RepoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_repo)
        val a=findViewById<TextView>(R.id.txtView)
        val b=intent.getStringExtra("issues")
        val c=intent.getIntExtra("open_issues",0)
        if(c==0)
            a.text= "There are no open issues for the current repository!"
        else
            a.text=b
    }
}